import portraitImage from "@/assets/dr-izhar-portrait.jpg";
import { Mail, Phone, Linkedin } from "lucide-react";
import DownloadPortfolio from "./DownloadPortfolio";

const Hero = () => {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-gradient-to-br from-background via-secondary/30 to-background">
      {/* Decorative elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-40 -right-40 w-96 h-96 bg-primary/10 rounded-full blur-3xl" />
        <div className="absolute -bottom-40 -left-40 w-96 h-96 bg-accent/10 rounded-full blur-3xl" />
      </div>

      <div className="container mx-auto px-6 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Text Content */}
          <div className="space-y-6 animate-fade-in">
            <div className="inline-block">
              <span className="px-4 py-2 bg-primary/10 text-primary rounded-full text-sm font-medium">
                DHA-Eligible • Available in Dubai
              </span>
            </div>
            
            <h1 className="text-5xl lg:text-6xl font-bold text-foreground leading-tight">
              Dr. Izhar Khan
            </h1>
            
            <p className="text-2xl text-primary font-medium">
              General Dentist
            </p>
            
            <p className="text-lg text-muted-foreground max-w-xl">
              Restorative, Cosmetic & Preventive Dentistry Specialist with 4+ years of experience
            </p>

            <div className="flex flex-wrap gap-4 pt-4">
              <a 
                href="tel:+971552310490"
                className="flex items-center gap-2 px-6 py-3 bg-primary text-primary-foreground rounded-lg hover:bg-primary-dark transition-all shadow-md hover:shadow-lg"
              >
                <Phone className="w-4 h-4" />
                <span>Call Now</span>
              </a>
              
              <a 
                href="mailto:dr.izharkhan.official@gmail.com"
                className="flex items-center gap-2 px-6 py-3 bg-secondary text-secondary-foreground rounded-lg hover:bg-muted transition-all border border-border"
              >
                <Mail className="w-4 h-4" />
                <span>Email</span>
              </a>
              
              <a 
                href="https://www.linkedin.com/in/dr-izhar-khan-58765b398"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 px-6 py-3 bg-accent text-accent-foreground rounded-lg hover:opacity-90 transition-all"
              >
                <Linkedin className="w-4 h-4" />
                <span>LinkedIn</span>
              </a>
            </div>

            {/* Download Portfolio Button */}
            <div className="pt-4">
              <DownloadPortfolio />
            </div>

            <div className="grid grid-cols-3 gap-6 pt-8 border-t border-border">
              <div>
                <p className="text-3xl font-bold text-primary">4+</p>
                <p className="text-sm text-muted-foreground">Years Experience</p>
              </div>
              <div>
                <p className="text-3xl font-bold text-primary">3000+</p>
                <p className="text-sm text-muted-foreground">Procedures</p>
              </div>
              <div>
                <p className="text-3xl font-bold text-primary">5</p>
                <p className="text-sm text-muted-foreground">Languages</p>
              </div>
            </div>
          </div>

          {/* Image */}
          <div className="relative animate-slide-in">
            <div className="absolute inset-0 bg-gradient-to-br from-primary to-accent rounded-3xl blur-2xl opacity-20" />
            <div className="relative rounded-3xl overflow-hidden shadow-2xl border border-border bg-card">
              <img 
                src={portraitImage} 
                alt="Dr. Izhar Khan - Professional Portrait" 
                className="w-full h-auto object-cover object-center"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
