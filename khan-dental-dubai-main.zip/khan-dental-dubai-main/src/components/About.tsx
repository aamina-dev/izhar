import { Heart, Users, Award, Globe } from "lucide-react";

const About = () => {
  return (
    <section className="py-24 bg-background" id="about">
      <div className="container mx-auto px-6">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-16 animate-fade-in">
            <h2 className="text-4xl font-bold text-foreground mb-4">About Dr. Izhar Khan</h2>
            <div className="w-20 h-1 bg-gradient-to-r from-primary to-accent mx-auto rounded-full" />
          </div>

          <div className="space-y-8">
            <div className="bg-card rounded-2xl p-8 shadow-md border border-border animate-fade-in">
              <p className="text-lg text-foreground leading-relaxed">
                I'm Dr. Izhar Khan, a <span className="text-primary font-semibold">DHA-eligible General Dentist</span> based in Dubai. 
                Over the past four years, I've worked in fast-paced clinics and handled more than <span className="text-primary font-semibold">3000+ procedures</span> — 
                everything from restorative and cosmetic work to preventive and endodontic treatments.
              </p>
              
              <p className="text-lg text-foreground leading-relaxed mt-4">
                I focus on top-quality care and really try to make sure my patients feel comfortable and heard. 
                I love helping people feel good about their smiles. For me, every patient deserves empathy and honest, 
                straightforward communication.
              </p>

              <p className="text-lg text-foreground leading-relaxed mt-4">
                I speak English, Hindi, Urdu, Pashto, and Punjabi, so I'm used to connecting with Dubai's diverse community. 
                Right now, I'm looking for a <span className="text-primary font-semibold">General Dentist position in Dubai</span> where 
                I can bring my experience, learn alongside a great team, and keep putting patients first.
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="bg-card rounded-xl p-6 text-center shadow-sm border border-border hover:shadow-md transition-all animate-fade-in">
                <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Heart className="w-6 h-6 text-primary" />
                </div>
                <h3 className="font-semibold text-foreground mb-2">Patient-Centered</h3>
                <p className="text-sm text-muted-foreground">Empathy and comfort in every treatment</p>
              </div>

              <div className="bg-card rounded-xl p-6 text-center shadow-sm border border-border hover:shadow-md transition-all animate-fade-in">
                <div className="w-12 h-12 bg-accent/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Users className="w-6 h-6 text-accent" />
                </div>
                <h3 className="font-semibold text-foreground mb-2">Team Player</h3>
                <p className="text-sm text-muted-foreground">Collaborative multidisciplinary approach</p>
              </div>

              <div className="bg-card rounded-xl p-6 text-center shadow-sm border border-border hover:shadow-md transition-all animate-fade-in">
                <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Award className="w-6 h-6 text-primary" />
                </div>
                <h3 className="font-semibold text-foreground mb-2">Detail-Oriented</h3>
                <p className="text-sm text-muted-foreground">Precision in every procedure</p>
              </div>

              <div className="bg-card rounded-xl p-6 text-center shadow-sm border border-border hover:shadow-md transition-all animate-fade-in">
                <div className="w-12 h-12 bg-accent/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Globe className="w-6 h-6 text-accent" />
                </div>
                <h3 className="font-semibold text-foreground mb-2">Multilingual</h3>
                <p className="text-sm text-muted-foreground">5 languages for diverse patients</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
