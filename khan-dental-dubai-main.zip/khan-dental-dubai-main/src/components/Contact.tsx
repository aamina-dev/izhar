import { Mail, Phone, Linkedin, MapPin } from "lucide-react";

const Contact = () => {
  // replace this number if needed (without + or leading zeros in wa.me)
  const phoneE164 = "971552310490";
  const displayPhone = "+971 55 231 0490";

  // whatsapp web link (works on desktop and mobile)
  const whatsappLink = `https://api.whatsapp.com/send?phone=${phoneE164}&text=${encodeURIComponent(
    "Hi, I'm contacting regarding General Dentist opportunities. - Dr. Izhar Khan"
  )}`;

  // mailto with simple subject (you can remove body or subject if you want)
  const mailto = `mailto:dr.izharkhan.official@gmail.com?subject=${encodeURIComponent(
    "Application: General Dentist - Dr. Izhar Khan"
  )}`;

  return (
    <section
      className="py-24 bg-gradient-to-br from-primary to-accent text-primary-foreground"
      id="contact"
    >
      <div className="container mx-auto px-6">
        <div className="max-w-4xl mx-auto text-center">
          <div className="mb-12 animate-fade-in">
            <h2 className="text-4xl font-bold mb-4">Let's Connect</h2>
            <p className="text-xl opacity-90">
              Available for General Dentist positions in Dubai • Immediate Joiner
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-6 mb-12">
            {/* PRIMARY ACTION: WhatsApp (works on desktop + mobile) */}
            <a
              href={whatsappLink}
              target="_blank"
              rel="noopener noreferrer"
              aria-label="Message on WhatsApp"
              className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 hover:bg-white/20 transition-all border border-white/20 group animate-fade-in"
            >
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 bg-white/20 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                  <Phone className="w-7 h-7" />
                </div>
                <div className="text-left">
                  <p className="text-sm opacity-80 mb-1">Call or WhatsApp</p>
                  <p className="text-lg font-semibold">{displayPhone}</p>
                </div>
              </div>
            </a>

            {/* Email */}
            <a
              href={mailto}
              aria-label="Send email"
              className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 hover:bg-white/20 transition-all border border-white/20 group animate-fade-in"
              style={{ animationDelay: "0.1s" }}
            >
              <div className="flex items-center gap-4">
                <div className="w-14 h-14 bg-white/20 rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                  <Mail className="w-7 h-7" />
                </div>
                <div className="text-left">
                  <p className="text-sm opacity-80 mb-1">Email</p>
                  <p className="text-lg font-semibold break-all">
                    dr.izharkhan.official@gmail.com
                  </p>
                </div>
              </div>
            </a>
          </div>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-6 mb-12">
            <a
              href="https://www.linkedin.com/in/dr-izhar-khan-58765b398"
              target="_blank"
              rel="noopener noreferrer"
              aria-label="Open LinkedIn profile"
              className="inline-flex items-center gap-3 bg-white/10 backdrop-blur-sm px-6 py-3 rounded-xl hover:bg-white/20 transition-all border border-white/20 animate-fade-in"
              style={{ animationDelay: "0.2s" }}
            >
              <Linkedin className="w-5 h-5" />
              <span className="font-semibold">Connect on LinkedIn</span>
            </a>

            <div
              className="inline-flex items-center gap-3 bg-white/10 backdrop-blur-sm px-6 py-3 rounded-xl border border-white/20 animate-fade-in"
              style={{ animationDelay: "0.3s" }}
            >
              <MapPin className="w-5 h-5" />
              <span className="font-semibold">Currently in Dubai, UAE</span>
            </div>
          </div>

          <div
            className="bg-white/10 backdrop-blur-sm rounded-2xl p-8 border border-white/20 animate-fade-in"
            style={{ animationDelay: "0.4s" }}
          >
            <h3 className="text-2xl font-bold mb-4">Ready to Join Your Team</h3>
            <p className="text-lg opacity-90 mb-6">
              DHA-eligible with 4+ years experience • 3000+ procedures • Multilingual • Immediate
              availability
            </p>
            <div className="flex flex-wrap justify-center gap-3">
              <span className="px-4 py-2 bg-white/20 rounded-full text-sm font-semibold">
                Restorative Dentistry
              </span>
              <span className="px-4 py-2 bg-white/20 rounded-full text-sm font-semibold">
                Cosmetic Dentistry
              </span>
              <span className="px-4 py-2 bg-white/20 rounded-full text-sm font-semibold">
                Endodontics
              </span>
              <span className="px-4 py-2 bg-white/20 rounded-full text-sm font-semibold">
                Patient Care
              </span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;
