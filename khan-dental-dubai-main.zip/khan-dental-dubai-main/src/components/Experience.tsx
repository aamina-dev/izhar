import { Briefcase, Calendar } from "lucide-react";

const Experience = () => {
  const experiences = [
    {
      title: "General Dentist",
      company: "Rawal Institute of Health Sciences",
      location: "Islamabad, Pakistan",
      period: "October 2022 - March 2025",
      duration: "2 years 6 months",
      current: false,
      responsibilities: [
        "Conducted general, restorative, and preventive dental treatments",
        "Managed diverse patients in a high-volume clinical setting",
        "Trained junior staff on patient handling and chairside assistance",
        "Enhanced patient retention through effective follow-up and counseling"
      ]
    },
    {
      title: "House Officer",
      company: "Rawal Institute of Health Sciences",
      location: "Islamabad, Pakistan",
      period: "April 2025 - Present",
      duration: "8 months",
      current: true,
      responsibilities: [
        "Assisted in multidisciplinary dental cases under supervision of senior faculty",
        "Gained experience in prosthodontics, periodontics, and oral surgery rotations"
      ]
    },
    {
      title: "General Dentist",
      company: "Dental Art Clinic Islamabad",
      location: "Islamabad, Pakistan",
      period: "January 2021 - December 2022",
      duration: "2 years",
      current: false,
      responsibilities: [
        "Performed 1500+ restorative, endodontic, and cosmetic dental procedures",
        "Maintained 100% compliance with sterilization and infection control protocols",
        "Collaborated with orthodontists and prosthodontists for complex cases",
        "Delivered excellent patient satisfaction and follow-up care"
      ]
    }
  ];

  return (
    <section className="py-24 bg-gradient-to-br from-secondary/30 to-background" id="experience">
      <div className="container mx-auto px-6">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-16 animate-fade-in">
            <h2 className="text-4xl font-bold text-foreground mb-4">Professional Experience</h2>
            <div className="w-20 h-1 bg-gradient-to-r from-primary to-accent mx-auto rounded-full" />
            <p className="mt-6 text-lg text-muted-foreground">
              Over 4 years of comprehensive dental practice
            </p>
          </div>

          <div className="relative">
            {/* Timeline line */}
            <div className="absolute left-8 top-0 bottom-0 w-0.5 bg-primary/20 hidden md:block" />

            <div className="space-y-12">
              {experiences.map((exp, index) => (
                <div 
                  key={index}
                  className="relative animate-fade-in"
                  style={{ animationDelay: `${index * 0.15}s` }}
                >
                  {/* Timeline dot */}
                  <div className="absolute left-6 top-6 w-5 h-5 bg-primary rounded-full border-4 border-background hidden md:block z-10" />
                  
                  <div className="md:ml-20 bg-card rounded-2xl p-6 shadow-md border border-border hover:shadow-lg transition-all">
                    <div className="flex flex-wrap items-start justify-between gap-4 mb-4">
                      <div>
                        <h3 className="text-2xl font-bold text-foreground mb-2">{exp.title}</h3>
                        <div className="flex items-center gap-2 text-primary font-semibold mb-2">
                          <Briefcase className="w-4 h-4" />
                          <span>{exp.company}</span>
                        </div>
                        <p className="text-sm text-muted-foreground">{exp.location}</p>
                      </div>
                      
                      <div className="text-right">
                        <div className="flex items-center gap-2 text-muted-foreground mb-2">
                          <Calendar className="w-4 h-4" />
                          <span className="text-sm">{exp.period}</span>
                        </div>
                        {exp.current && (
                          <span className="inline-block px-3 py-1 bg-accent/20 text-accent rounded-full text-xs font-semibold">
                            Current
                          </span>
                        )}
                        <p className="text-xs text-muted-foreground mt-1">{exp.duration}</p>
                      </div>
                    </div>

                    <ul className="space-y-2">
                      {exp.responsibilities.map((resp, idx) => (
                        <li key={idx} className="flex items-start gap-2 text-foreground">
                          <span className="text-primary mt-1">•</span>
                          <span>{resp}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Experience;
