import { Download } from "lucide-react";
import { Button } from "@/components/ui/button";
import html2pdf from "html2pdf.js";

const DownloadPortfolio = () => {
  const handleDownload = () => {
    const element = document.getElementById("portfolio-content");
    
    const opt = {
      margin: 0.5,
      filename: 'Dr_Izhar_Khan_Portfolio.pdf',
      image: { type: 'jpeg' as const, quality: 0.98 },
      html2canvas: { scale: 2, useCORS: true, logging: false },
      jsPDF: { unit: 'in', format: 'a4', orientation: 'portrait' as const }
    };

    html2pdf().set(opt).from(element).save();
  };

  return (
    <Button
      onClick={handleDownload}
      size="lg"
      className="bg-white text-primary hover:bg-white/90 font-semibold px-8 py-6 text-lg shadow-xl"
    >
      <Download className="w-5 h-5 mr-2" />
      Download Portfolio PDF
    </Button>
  );
};

export default DownloadPortfolio;
