import { Award, CheckCircle } from "lucide-react";

const Certifications = () => {
  const certifications = [
    {
      name: "DHA Eligibility",
      issuer: "Dubai Health Authority",
      highlight: true
    },
    {
      name: "Basic Life Support (BLS)",
      issuer: "Certified Provider"
    },
    {
      name: "Personal Protective Equipment (PPE)",
      issuer: "Infection Control Certification"
    },
    {
      name: "Endodontics Rotary and Restorative Dentistry",
      issuer: "Advanced Training"
    }
  ];

  return (
    <section className="py-24 bg-background" id="certifications">
      <div className="container mx-auto px-6">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-16 animate-fade-in">
            <div className="inline-flex items-center gap-2 mb-4">
              <Award className="w-8 h-8 text-primary" />
              <h2 className="text-4xl font-bold text-foreground">Certifications</h2>
            </div>
            <div className="w-20 h-1 bg-gradient-to-r from-primary to-accent mx-auto rounded-full" />
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            {certifications.map((cert, index) => (
              <div 
                key={index}
                className={`rounded-2xl p-6 shadow-md border transition-all hover:shadow-lg animate-fade-in ${
                  cert.highlight 
                    ? 'bg-gradient-to-br from-primary/10 to-accent/10 border-primary/30' 
                    : 'bg-card border-border'
                }`}
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <div className="flex items-start gap-4">
                  <div className={`w-12 h-12 rounded-full flex items-center justify-center flex-shrink-0 ${
                    cert.highlight ? 'bg-primary/20' : 'bg-muted'
                  }`}>
                    <CheckCircle className={`w-6 h-6 ${cert.highlight ? 'text-primary' : 'text-accent'}`} />
                  </div>
                  <div>
                    <h3 className="font-bold text-foreground text-lg mb-2">{cert.name}</h3>
                    <p className="text-sm text-muted-foreground">{cert.issuer}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-12 text-center">
            <div className="inline-block bg-accent/10 rounded-xl px-6 py-4 border border-accent/30">
              <p className="text-accent font-semibold">✓ Ready for Immediate Placement</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Certifications;
