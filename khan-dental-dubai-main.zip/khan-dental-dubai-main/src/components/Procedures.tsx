import { Activity } from "lucide-react";

const Procedures = () => {
  const procedures = [
    { name: "Fillings", count: "800+" },
    { name: "Scaling & Polishing", count: "900+" },
    { name: "Molar RCTs", count: "300+" },
    { name: "Veneers", count: "150+" },
    { name: "Crown & Bridge Work", count: "250+" },
    { name: "Extractions", count: "400+" },
    { name: "Teeth Whitening", count: "200+" },
    { name: "Emergency Management", count: "100+" }
  ];

  return (
    <section className="py-24 bg-gradient-to-br from-secondary/30 to-background" id="procedures">
      <div className="container mx-auto px-6">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-16 animate-fade-in">
            <div className="inline-flex items-center gap-2 mb-4">
              <Activity className="w-8 h-8 text-accent" />
              <h2 className="text-4xl font-bold text-foreground">Procedures Performed</h2>
            </div>
            <div className="w-20 h-1 bg-gradient-to-r from-primary to-accent mx-auto rounded-full" />
            <p className="mt-6 text-lg text-muted-foreground">
              3000+ total procedures across all specialties
            </p>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {procedures.map((procedure, index) => (
              <div 
                key={index}
                className="bg-card rounded-xl p-6 shadow-md border border-border hover:shadow-lg hover:border-primary/30 transition-all text-center animate-fade-in"
                style={{ animationDelay: `${index * 0.05}s` }}
              >
                <div className="mb-4">
                  <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-primary/20 to-accent/20 rounded-full">
                    <span className="text-2xl font-bold text-primary">{procedure.count}</span>
                  </div>
                </div>
                <h3 className="font-semibold text-foreground text-lg">{procedure.name}</h3>
              </div>
            ))}
          </div>

          <div className="mt-16 text-center">
            <div className="inline-block bg-card rounded-2xl px-8 py-6 shadow-md border border-border">
              <p className="text-sm text-muted-foreground mb-2">Total Procedures</p>
              <p className="text-5xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
                3000+
              </p>
              <p className="text-sm text-muted-foreground mt-2">Successful Treatments Completed</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Procedures;
