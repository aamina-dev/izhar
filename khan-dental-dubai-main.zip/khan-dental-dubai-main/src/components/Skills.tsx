import { CheckCircle2 } from "lucide-react";

const Skills = () => {
  const skills = [
    "Restorative Dentistry",
    "Cosmetic Dentistry",
    "Endodontics (Including Molar RCTs)",
    "Extractions",
    "Crowns, Bridges & Veneers",
    "Preventive Dentistry",
    "Chairside Ethics & Patient Communication",
    "Infection Control & Sterilization Compliance",
    "Multidisciplinary Case Handling",
    "Teeth Whitening & Aesthetics",
    "Root Canal Treatments",
    "Emergency Dental Management"
  ];

  return (
    <section className="py-24 bg-gradient-to-br from-secondary/30 to-background" id="skills">
      <div className="container mx-auto px-6">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-16 animate-fade-in">
            <h2 className="text-4xl font-bold text-foreground mb-4">Key Skills & Expertise</h2>
            <div className="w-20 h-1 bg-gradient-to-r from-primary to-accent mx-auto rounded-full" />
            <p className="mt-6 text-lg text-muted-foreground">
              Comprehensive dental care with expertise in restorative, cosmetic, and preventive treatments
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            {skills.map((skill, index) => (
              <div 
                key={index}
                className="flex items-start gap-3 bg-card rounded-xl p-4 shadow-sm border border-border hover:shadow-md hover:border-primary/30 transition-all animate-fade-in"
                style={{ animationDelay: `${index * 0.05}s` }}
              >
                <CheckCircle2 className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                <span className="text-foreground font-medium">{skill}</span>
              </div>
            ))}
          </div>

          <div className="mt-16 bg-card rounded-2xl p-8 shadow-md border border-border animate-fade-in">
            <h3 className="text-2xl font-bold text-foreground mb-6 text-center">Languages</h3>
            <div className="flex flex-wrap justify-center gap-4">
              {[
                { lang: "English", level: "Professional Working" },
                { lang: "Urdu", level: "Native" },
                { lang: "Hindi", level: "Native" },
                { lang: "Pashto", level: "Native" },
                { lang: "Punjabi", level: "Limited Working" }
              ].map((item, index) => (
                <div 
                  key={index}
                  className="bg-primary/5 rounded-lg px-5 py-3 border border-primary/20"
                >
                  <p className="font-semibold text-foreground">{item.lang}</p>
                  <p className="text-sm text-muted-foreground">{item.level}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Skills;
