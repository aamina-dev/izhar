import { Heart, MessageCircle, Shield, Smile } from "lucide-react";

const Philosophy = () => {
  const values = [
    {
      icon: Heart,
      title: "Empathy First",
      description: "Understanding that every patient has unique concerns and needs"
    },
    {
      icon: Smile,
      title: "Comfort-Focused",
      description: "Creating a relaxed environment where patients feel safe and cared for"
    },
    {
      icon: MessageCircle,
      title: "Transparent Communication",
      description: "Clear explanations and honest discussions about treatment options"
    },
    {
      icon: Shield,
      title: "Patient Satisfaction",
      description: "Committed to delivering results that exceed expectations"
    }
  ];

  return (
    <section className="py-24 bg-background" id="philosophy">
      <div className="container mx-auto px-6">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-16 animate-fade-in">
            <h2 className="text-4xl font-bold text-foreground mb-4">Patient Care Philosophy</h2>
            <div className="w-20 h-1 bg-gradient-to-r from-primary to-accent mx-auto rounded-full" />
          </div>

          <div className="bg-gradient-to-br from-primary/5 to-accent/5 rounded-3xl p-8 md:p-12 shadow-lg border border-primary/10 mb-12 animate-fade-in">
            <blockquote className="text-xl md:text-2xl text-foreground text-center leading-relaxed">
              "For me, dentistry is more than just procedures — it's about building trust, 
              relieving anxiety, and helping people smile with confidence. Every patient deserves 
              compassionate care delivered with precision and integrity."
            </blockquote>
            <p className="text-center mt-6 text-lg font-semibold text-primary">
              — Dr. Izhar Khan
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            {values.map((value, index) => (
              <div 
                key={index}
                className="bg-card rounded-2xl p-6 shadow-md border border-border hover:shadow-lg transition-all animate-fade-in"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0">
                    <value.icon className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-foreground mb-2">{value.title}</h3>
                    <p className="text-muted-foreground">{value.description}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Philosophy;
