import surgeryImage from "@/assets/clinical-surgery.jpg";
import procedureImage from "@/assets/clinical-procedure.jpg";
import { Stethoscope } from "lucide-react";

const ClinicalCases = () => {
  const cases = [
    {
      title: "Surgical Procedure",
      image: surgeryImage,
      description: "Demonstration of precision and teamwork during oral surgical assistance",
      category: "Oral Surgery"
    },
    {
      title: "Trauma Management & Fixation",
      image: procedureImage,
      description: "Successful fixation plate procedure for dental trauma case",
      category: "Restorative"
    }
  ];

  return (
    <section className="py-24 bg-background" id="cases">
      <div className="container mx-auto px-6">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16 animate-fade-in">
            <div className="inline-flex items-center gap-2 mb-4">
              <Stethoscope className="w-8 h-8 text-primary" />
              <h2 className="text-4xl font-bold text-foreground">Clinical Cases Portfolio</h2>
            </div>
            <div className="w-20 h-1 bg-gradient-to-r from-primary to-accent mx-auto rounded-full" />
            <p className="mt-6 text-lg text-muted-foreground">
              Real-world cases demonstrating expertise and precision
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {cases.map((caseItem, index) => (
              <div 
                key={index}
                className="group bg-card rounded-2xl overflow-hidden shadow-md border border-border hover:shadow-xl transition-all animate-fade-in"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <div className="relative overflow-hidden aspect-[4/3]">
                  <img 
                    src={caseItem.image}
                    alt={caseItem.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute top-4 left-4">
                    <span className="px-3 py-1 bg-primary text-primary-foreground rounded-full text-xs font-semibold">
                      {caseItem.category}
                    </span>
                  </div>
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-bold text-foreground mb-3">{caseItem.title}</h3>
                  <p className="text-muted-foreground">{caseItem.description}</p>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-12 bg-gradient-to-br from-primary/10 to-accent/10 rounded-2xl p-8 border border-primary/20 animate-fade-in">
            <div className="text-center">
              <h3 className="text-2xl font-bold text-foreground mb-4">
                Combining Skill, Empathy, and Precision
              </h3>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                Every procedure is performed with attention to detail, patient comfort, and commitment to delivering quality dental care
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ClinicalCases;
