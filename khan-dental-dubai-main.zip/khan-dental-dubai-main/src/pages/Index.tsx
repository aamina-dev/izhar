import Hero from "@/components/Hero";
import About from "@/components/About";
import Skills from "@/components/Skills";
import Certifications from "@/components/Certifications";
import Experience from "@/components/Experience";
import ClinicalCases from "@/components/ClinicalCases";
import Procedures from "@/components/Procedures";
import Philosophy from "@/components/Philosophy";
import Contact from "@/components/Contact";

const Index = () => {
  return (
    <main className="min-h-screen" id="portfolio-content">
      <Hero />
      <About />
      <Skills />
      <Certifications />
      <Experience />
      <ClinicalCases />
      <Procedures />
      <Philosophy />
      <Contact />
      
      {/* Footer */}
      <footer className="bg-foreground text-background py-8">
        <div className="container mx-auto px-6 text-center">
          <p className="text-sm opacity-80">
            © 2025 Dr. Izhar Khan • DHA-Eligible General Dentist • Dubai, UAE
          </p>
        </div>
      </footer>
    </main>
  );
};

export default Index;
